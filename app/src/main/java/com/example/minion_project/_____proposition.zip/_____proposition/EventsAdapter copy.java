package com.example.eventPlanner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.EventViewHolder> {

    private final Context context;
    private final List<Event> eventList;

    // Constructor
    public EventsAdapter(Context context, ArrayList<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Get the event at the specified position
        Event event = eventList.get(position);

        // Bind event data to views
        holder.eventName.setText(event.getName());
        holder.eventDate.setText(event.getDate());
        holder.eventTime.setText(event.getTime());
        holder.eventLocation.setText(event.getCity() + ", " + event.getProvince() + ", " + event.getCountry());
        holder.eventDescription.setText(event.getDescription());
        holder.eventCapacity.setText("Capacity: " + event.getCapacity());

        // Check if the organizer is not null
        if (event.getOrganizerId() != null) {
            holder.eventOrganizer.setText("Organizer: " + event.getOrganizerId().getSelf().getName());
        } else {
            holder.eventOrganizer.setText("Organizer: Unknown");
        }

        // Use a placeholder image for the event image (as there's no image URL in Event class)
        holder.eventImage.setImageResource(R.drawable.baseline_tag_faces); // Replace with actual drawable
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // ViewHolder class
    static class EventViewHolder extends RecyclerView.ViewHolder {

        ImageView eventImage;
        TextView eventName, eventDate, eventTime, eventLocation,
                eventDescription, eventCapacity, eventOrganizer;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize views
            eventImage = itemView.findViewById(R.id.eventImage);
            eventName = itemView.findViewById(R.id.eventName);
            eventDate = itemView.findViewById(R.id.eventDate);
            eventTime = itemView.findViewById(R.id.eventTime);
            eventLocation = itemView.findViewById(R.id.eventLocation);
            eventDescription = itemView.findViewById(R.id.eventDescription);
            eventCapacity = itemView.findViewById(R.id.eventCapacity);
            eventOrganizer = itemView.findViewById(R.id.eventOrganizer);
        }
    }
}
