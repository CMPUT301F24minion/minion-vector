package com.example.eventPlanner;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class WelcomeBackFragment extends Fragment {
    private static final String TAG = "WelcomeBackFragment";
    private String deviceId;
    private TextView welcomeBackTextView;
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.welcome_back, container, false);

        // Initialize Firebase Firestore and TextView
        db = FirebaseFirestore.getInstance();
        welcomeBackTextView = view.findViewById(R.id.welcomeBackTextView);

        // Set the entire screen as clickable
        view.setOnClickListener(v -> {
            // Navigate to SelectViewFragment using NavController
            NavHostFragment.findNavController(WelcomeBackFragment.this)
                    .navigate(R.id.action_welcomeBackFragment_to_selectViewFragment);
        });

        // Get the unique device ID
        deviceId = Settings.Secure.getString(requireActivity().getContentResolver(), Settings.Secure.ANDROID_ID);

        // Load the user's name from the database
        loadUserName();

        return view;
    }

    private void loadUserName() {
        db.collection("Users").document(deviceId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document != null && document.exists()) {
                            String userName = document.getString("name");
                            if (userName != null) {
                                welcomeBackTextView.setText("Welcome back, " + userName + "!");
                            }
                        } else {
                            Log.d(TAG, "Device ID not found in database.");
                        }
                    } else {
                        Log.w(TAG, "Error fetching user data.", task.getException());
                    }
                });
    }
}
