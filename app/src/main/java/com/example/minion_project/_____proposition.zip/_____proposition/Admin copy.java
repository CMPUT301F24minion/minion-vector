package com.example.eventPlanner;

public class Admin extends User {
    private String adminId;
}
