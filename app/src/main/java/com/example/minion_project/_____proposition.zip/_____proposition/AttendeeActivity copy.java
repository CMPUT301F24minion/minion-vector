package com.example.eventPlanner;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

public class AttendeeActivity extends AppCompatActivity {

    private NavController navController;  // Declare NavController

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendee);  // Set the layout for this activity

        // Initialize NavController for attendee fragments
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment_attendee);
        navController = navHostFragment.getNavController();
    }
}
