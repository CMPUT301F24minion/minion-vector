package com.example.eventPlanner;

import java.util.ArrayList;

public class Organizer {
    private String organizerId;
    private ArrayList<Event> eventsOrganized;
    private User self;

    public Organizer(User self) {
        this.self = self;
        this.organizerId = self.getDeviceId();
        this.eventsOrganized = new ArrayList<Event>();
    }

    public String getDeviceId() {
        return self.getDeviceId();
    }

    public User getSelf() {
        return this.self;
    }
}

