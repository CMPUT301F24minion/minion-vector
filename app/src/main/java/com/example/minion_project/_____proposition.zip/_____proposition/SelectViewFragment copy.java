package com.example.eventPlanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class SelectViewFragment extends Fragment {

    private RadioGroup selectViewRadioGroup;
    private Button jumpToRequestedViewLandingPageButton;

    public SelectViewFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.select_view, container, false);

        // Initialize UI components
        selectViewRadioGroup = view.findViewById(R.id.selectViewRadioGroup);
        jumpToRequestedViewLandingPageButton = view.findViewById(R.id.jumpToRequestedViewLandingPageButton);

        // Set up click listener for the button
        jumpToRequestedViewLandingPageButton.setOnClickListener(v -> {
            int selectedId = selectViewRadioGroup.getCheckedRadioButtonId();

            if (selectedId == R.id.selectAttendeeViewRadioButton) {
                // Navigate to AttendeeAttendingFragment using action ID
                NavHostFragment.findNavController(SelectViewFragment.this)
                        .navigate(R.id.action_selectViewFragment_to_attendeeAttendingFragment);
            } else if (selectedId == R.id.selectOrganizerViewRadioButton) {
                // Handle organizer selection (add navigation action if needed)
                // NavHostFragment.findNavController(SelectViewFragment.this)
                //     .navigate(R.id.action_selectViewFragment_to_organizerFragment);
                Toast.makeText(getContext(), "Organizer view is not yet implemented.", Toast.LENGTH_SHORT).show();
            } else {
                // No radio button selected
                Toast.makeText(getContext(), "Please select a view.", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
