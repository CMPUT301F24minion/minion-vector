package com.example.eventPlanner;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private FirebaseFirestore db;
    private String deviceId;
    private NavController navController;  // Declare NavController

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize NavController
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        // Initialize Firebase Firestore
        db = FirebaseFirestore.getInstance();

        // Get the unique device ID
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        // Check if the device exists in Firebase
        checkDeviceInDatabase();
    }

    private void checkDeviceInDatabase() {
        db.collection("Users").document(deviceId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document != null && document.exists()) {
                            Log.d(TAG, "Device ID found in database. Showing Welcome Back screen.");
                            navController.navigate(R.id.welcomeBackFragment);
                        } else {
                            Log.d(TAG, "Device ID not found in database. Showing Welcome screen.");
                            navController.navigate(R.id.welcomeFragment);
                        }
                    } else {
                        Log.w(TAG, "Error checking device ID in database.", task.getException());
                    }
                });
    }
}
