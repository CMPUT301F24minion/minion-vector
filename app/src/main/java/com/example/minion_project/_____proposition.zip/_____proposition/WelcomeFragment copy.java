package com.example.eventPlanner;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.appcompat.app.AlertDialog;

import android.provider.Settings;
import android.content.Context;

import com.google.firebase.firestore.FirebaseFirestore;

public class WelcomeFragment extends Fragment {

    private FirebaseFirestore db;
    private static final String TAG = "WelcomeFragment";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance();  // Initialize Firebase Firestore
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the welcome.xml layout for this fragment
        View rootView = inflater.inflate(R.layout.welcome, container, false);

        // Find the root layout and set an onClickListener
        View rootLayout = rootView.findViewById(R.id.rootLayout);

        // Set an OnClickListener to detect clicks anywhere on the screen
        rootLayout.setOnClickListener(v -> {
            // Show a dialog to prompt the user for their information
            newUserSignUpDialog();
        });

        return rootView;
    }

    private void newUserSignUpDialog() {
        // Create an AlertDialog Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());

        // Inflate the custom layout
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.welcome_dialog, null);

        // Find the EditText fields in the custom layout
        final EditText nameInput = dialogView.findViewById(R.id.nameInput);
        final EditText emailInput = dialogView.findViewById(R.id.emailInput);
        final EditText phoneNumberInput = dialogView.findViewById(R.id.phoneNumberInput);
        final EditText locationInput = dialogView.findViewById(R.id.locationInput);
        final CheckBox attendeePermissionsCheckBox = dialogView.findViewById(R.id.attendeePermissionsCheckBox);
        final CheckBox organizerPermissionsCheckBox = dialogView.findViewById(R.id.organizerPermissionsCheckBox);

        // Set the custom layout to the dialog
        builder.setView(dialogView);

        // Set "Submit" button
        builder.setPositiveButton("Submit", (dialog, which) -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String phoneNumber = phoneNumberInput.getText().toString().trim();
            String location = locationInput.getText().toString().trim();

            User newUser = new User(getDeviceId(getContext()), name, email, phoneNumber, location);

            if (attendeePermissionsCheckBox.isChecked()) {
                newUser.setAttendee(true);
                Attendee newAttendee = new Attendee(newUser);
                db.collection("Attendees")
                        .document(newAttendee.getSelf().getDeviceId())
                        .set(newAttendee);
            }

            if (organizerPermissionsCheckBox.isChecked()) {
                newUser.setOrganizer(true);
                Organizer newOrganizer = new Organizer(newUser);
                db.collection("Organizers")
                        .document(newOrganizer.getSelf().getDeviceId())
                        .set(newOrganizer);
            }

            // Save the User document after setting the roles
            db.collection("Users")
                    .document(newUser.getDeviceId())
                    .set(newUser);

            // Display or process the entered information
            Toast.makeText(requireContext(), "Welcome " + name + "!", Toast.LENGTH_LONG).show();

            // Navigate to SelectViewFragment
            NavHostFragment.findNavController(WelcomeFragment.this)
                    .navigate(R.id.action_welcomeFragment_to_selectViewFragment);
        });

        // Set "Cancel" button
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        // Show the AlertDialog
        builder.show();
    }

    public String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }
}
