package com.example.eventPlanner;

import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class AttendeeAttendingFragment extends Fragment {

    private RecyclerView eventsRecyclerView;
    private EventsAdapter eventsAdapter;
    private ArrayList<Event> eventList;
    private FirebaseFirestore db;

    public AttendeeAttendingFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.attendee_attending, container, false);

        eventsRecyclerView = view.findViewById(R.id.eventsRecyclerView);
        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        eventList = new ArrayList<>();
        eventsAdapter = new EventsAdapter(getContext(), eventList);
        eventsRecyclerView.setAdapter(eventsAdapter);

        db = FirebaseFirestore.getInstance();

        // Fetch and display events
        fetchAttendingEvents();

        return view;
    }

    private void fetchAttendingEvents() {
        String deviceId = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ANDROID_ID);

        db.collection("Attendees").document(deviceId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    Attendee attendee = documentSnapshot.toObject(Attendee.class);
                    if (attendee != null && attendee.getEventsAttending() != null) {
                        eventList.clear();
                        eventList.addAll(attendee.getEventsAttending());
                        eventsAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(getContext(), "No attending events found.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to load events.", Toast.LENGTH_SHORT).show();
                });
    }
}
