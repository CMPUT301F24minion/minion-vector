package com.example.eventPlanner;
import static java.lang.Boolean.TRUE;
import android.app.Notification;
import java.util.ArrayList;
import java.util.HashMap;

public class User { // represents a basic template for all application users
    private String deviceId;
    private String name;
    private String email;
    private String location;
    private boolean allowNotification;
    private String phoneNumber;
    private ArrayList<Event> attendingEvents;
    private ArrayList<Event> waitlistedEvents;
    private ArrayList<Notification> notificationsArrayList;
    private HashMap<String, String> allEvents;
    private HashMap<String, ArrayList> notifications;
    boolean isAttendee = false;
    boolean isOrganizer = false;

    public boolean isOrganizer() {
        return isOrganizer;
    }

    public void setOrganizer(boolean organizer) {
        isOrganizer = organizer;
    }

    public boolean isAttendee() {
        return isAttendee;
    }

    public void setAttendee(boolean attendee) {
        isAttendee = attendee;
    }


    public User() { // constructor: on case returning user
        this.deviceId = "";
        this.name = "";
        this.email = "";
        this.location = "";
        this.allowNotification = TRUE;
        this.notifications = new HashMap<>();
        this.phoneNumber = "";
        this.attendingEvents = new ArrayList<>();
        this.allEvents = new HashMap<>();
        this.waitlistedEvents = new ArrayList<>();
        this.notificationsArrayList = new ArrayList<>();

    }

    public User(String deviceID,
                String name,
                String email,
                String phoneNumber,
                String location) { // constructor: on case new user
        this.deviceId = deviceID;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.attendingEvents = new ArrayList<>();
        this.waitlistedEvents = new ArrayList<>();
        this.notificationsArrayList = new ArrayList<>();
        this.location = location;
    }

    public HashMap<String, ArrayList> getNotifications() {
        return notifications;
    }

    public void setNotifications(HashMap<String, ArrayList> notifications) {
        this.notifications = notifications;
    }

    public HashMap<String, String> getAllEvents() {
        return allEvents;
    }

    public void setAllEvents(HashMap<String, String> allEvents) {
        this.allEvents = allEvents;
    }

    public ArrayList<Notification> getNotificationsArrayList() {
        return notificationsArrayList;
    }

    public void setNotificationsArrayList(ArrayList<Notification> notificationsArrayList) {
        this.notificationsArrayList = notificationsArrayList;
    }

    public ArrayList<Event> getWaitlistedEvents() {
        return waitlistedEvents;
    }

    public void setWaitlistedEvents(ArrayList<Event> waitlistedEvents) {
        this.waitlistedEvents = waitlistedEvents;
    }

    public ArrayList<Event> getAttendingEvents() {
        return attendingEvents;
    }

    public void setAttendingEvents(ArrayList<Event> attendingEvents) {
        this.attendingEvents = attendingEvents;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getAllowNotification() {
        return allowNotification;
    }

    public void setAllowNotification(Boolean allowNotification) {
        this.allowNotification = allowNotification;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
