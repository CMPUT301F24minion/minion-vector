package com.example.eventPlanner;

import java.util.ArrayList;

public class Event {
    private String eventId;
    private String date;
    private String time;
    private String name;
    private String description;
    private String street;
    private String city;
    private String province;
    private String country;
    private String postalCode;
    private int capacity;
    private Organizer organizerId;
    private ArrayList<Attendee> eventAttendees;
    private ArrayList<Attendee> eventWaitlist;

    public Event() { // default constructor
        this.eventId = "";
        this.date = "";
        this.time = "";
        this.name = "";
        this.description = "";
        this.street = "";
        this.city = "";
        this.province = "";
        this.country = "";
        this.postalCode = "";
        this.capacity = 0;
        this.organizerId = null;
        this.eventAttendees = new ArrayList<>();
        this.eventWaitlist = new ArrayList<>();
    }

    public Event(String eventId,
                 String date,
                 String time,
                 String name,
                 String description,
                 String street,
                 String city,
                 String province,
                 String country,
                 String postalCode,
                 int capacity,
                 Organizer organizerId,
                 ArrayList<Attendee> eventAttendees,
                 ArrayList<Attendee> eventWaitlist) { // parameterized constructor
        this.eventId = eventId;
        this.date = date;
        this.time = time;
        this.name = name;
        this.description = description;
        this.street = street;
        this.city = city;
        this.province = province;
        this.country = country;
        this.postalCode = postalCode;
        this.capacity = capacity;
        this.organizerId = organizerId;
        this.eventAttendees = eventAttendees;
        this.eventWaitlist = eventWaitlist;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Organizer getOrganizerId() {
        return organizerId;
    }

    public void setOrganizerId(Organizer organizerId) {
        this.organizerId = organizerId;
    }

    public ArrayList<Attendee> getEventAttendees() {
        return eventAttendees;
    }

    public void setEventAttendees(ArrayList<Attendee> eventAttendees) {
        this.eventAttendees = eventAttendees;
    }

    public ArrayList<Attendee> getEventWaitlist() {
        return eventWaitlist;
    }

    public void setEventWaitlist(ArrayList<Attendee> eventWaitlist) {
        this.eventWaitlist = eventWaitlist;
    }
}
