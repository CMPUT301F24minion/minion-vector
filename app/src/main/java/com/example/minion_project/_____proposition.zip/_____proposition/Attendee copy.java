package com.example.eventPlanner;

import java.util.ArrayList;

public class Attendee {
    private String attendeeId;
    private ArrayList<Event> eventsAttending;
    private User self;

    // **Add this public no-argument constructor**
    public Attendee() {
        // Initialize fields if necessary
        this.eventsAttending = new ArrayList<>();
    }

    public Attendee(User self) {
        this.self = self;
        this.attendeeId = self.getDeviceId();
        this.eventsAttending = new ArrayList<>();
    }

    // Existing methods...

    // Getter and setter for attendeeId
    public String getAttendeeId() {
        return attendeeId;
    }

    public void setAttendeeId(String attendeeId) {
        this.attendeeId = attendeeId;
    }

    // Getter and setter for eventsAttending
    public ArrayList<Event> getEventsAttending() {
        return eventsAttending;
    }

    public void setEventsAttending(ArrayList<Event> eventsAttending) {
        this.eventsAttending = eventsAttending;
    }

    // Getter and setter for self
    public User getSelf() {
        return self;
    }

    public void setSelf(User self) {
        this.self = self;
    }
}
